PaperWarden archive fixture
